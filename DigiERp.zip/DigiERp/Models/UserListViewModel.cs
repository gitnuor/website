﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DigiERp.Models
{
    public class UserListViewModel
    {
        public SysUserRegistration UserRegistration { get; set; }
        public HrmDepartment Department { get; set; }
        public HrmDesignation Designation { get; set; }
    }
}