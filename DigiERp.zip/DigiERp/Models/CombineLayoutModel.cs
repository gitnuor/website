﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DigiERp.Models
{
    public class CombineLayoutModel
    {
        public List<SysDynamicCompany> DynamicCompanies { get; set; }
        public List<SysDynamicModule> DynamicModules { get; set; }
    }
}