﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace DigiERp.Models
{
    public class CombineLoginModel
    {
        public SysUserRegistration UserRegistration { get; set; }
        public List<SysDynamicCompany> DynamicCompanies { get; set; }
    }
}