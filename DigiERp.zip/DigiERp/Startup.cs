﻿using Microsoft.Owin;
using Owin;

[assembly: OwinStartupAttribute(typeof(DigiERp.Startup))]
namespace DigiERp
{
    public partial class Startup
    {
        public void Configuration(IAppBuilder app)
        {
            ConfigureAuth(app);
        }
    }
}
