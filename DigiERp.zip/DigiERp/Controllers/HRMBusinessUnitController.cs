﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Migrations;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using DigiERp.Models;

namespace DigiERp.Controllers
{
    public class HRMBusinessUnitController : Controller
    {
        private DigiERPEntities db = new DigiERPEntities();

        public ActionResult Index()
        {
            ViewBag.UIList = db.SysDynamicUIs.Where(p => p.IsActive == true && p.ModuleId == 4).ToList();
            var businessUnit = db.HrmBusinessUnits.Where(b => b.IsActive == true).ToList();
            return View(businessUnit);
        }

     
        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include="UnitId,BusinessUnit,IsActive")] HrmBusinessUnit hrmbusinessunit)
        {
            if (ModelState.IsValid)
            {
                db.HrmBusinessUnits.Add(hrmbusinessunit);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(hrmbusinessunit);
        }

        // GET: /BusinessUnit/Edit/5
        public ActionResult EditById(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            HrmBusinessUnit hrmbusinessunit = db.HrmBusinessUnits.Find(id);
            if (hrmbusinessunit == null)
            {
                return HttpNotFound();
            }
            return View(hrmbusinessunit);
        }

        // POST: /BusinessUnit/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include="UnitId,BusinessUnit,IsActive")] HrmBusinessUnit hrmbusinessunit)
        {
            if (ModelState.IsValid)
            {
                db.Entry(hrmbusinessunit).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(hrmbusinessunit);
        }

        // GET: /BusinessUnit/Delete/5
        public ActionResult DeleteById(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            HrmBusinessUnit hrmbusinessunit = db.HrmBusinessUnits.Find(id);
            if (hrmbusinessunit == null)
            {
                return HttpNotFound();
            }
            return View(hrmbusinessunit);
        }

        // POST: /BusinessUnit/Delete/5
        [HttpPost, ActionName("Delete")]
        //[ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int? UnitId)
        {
            HrmBusinessUnit hrmbusinessunit = db.HrmBusinessUnits.Find(UnitId);
            hrmbusinessunit.IsActive = false;
            db.HrmBusinessUnits.AddOrUpdate(hrmbusinessunit);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
