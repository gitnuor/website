﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Migrations;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using DigiERp.Models;

namespace DigiERp.Controllers
{
    public class HRMGradeAndAllowanceController : Controller
    {
        private DigiERPEntities db = new DigiERPEntities();

        public ActionResult Index()
        {
            ViewBag.UIList = db.SysDynamicUIs.Where(m => (m.IsActive == true) && (m.ModuleId == 4)).ToList();
            var GradeAndAllowanceList = db.HrmGrades.Where(d => d.IsActive == true).ToList();
            return View(GradeAndAllowanceList);
        }

        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            HrmGrade hrmgrade = db.HrmGrades.Find(id);
            if (hrmgrade == null)
            {
                return HttpNotFound();
            }
            return View(hrmgrade);
        }

        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        //[ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include="GradeId,GradeCode,GradeName,StartingBasic,LastBasic,IncrementRate,MaxIncrement,MinBenifitIncrem,GradeGroupId,BankLimit,EntryUserId,EntryBy,EntryDate,UpdateBy,UpdateDate,DeleteBy,DeleteDate,CheckBy,CheckDate,CancelBy,CancelDate,ApproveBy,ApproveDate,IsActive,IsDeleted,IsApproved,IsCancel,WorkFollowPosition")] HrmGrade hrmgrade)
        {
            if (ModelState.IsValid)
            {
                db.HrmGrades.Add(hrmgrade);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(hrmgrade);
        }

        public ActionResult EditById(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            HrmGrade hrmgrade = db.HrmGrades.Find(id);
            if (hrmgrade == null)
            {
                return HttpNotFound();
            }
            return View(hrmgrade);
        }

        [HttpPost]
        //[ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include="GradeId,GradeCode,GradeName,StartingBasic,LastBasic,IncrementRate,MaxIncrement,MinBenifitIncrem,GradeGroupId,BankLimit,EntryUserId,EntryBy,EntryDate,UpdateBy,UpdateDate,DeleteBy,DeleteDate,CheckBy,CheckDate,CancelBy,CancelDate,ApproveBy,ApproveDate,IsActive,IsDeleted,IsApproved,IsCancel,WorkFollowPosition")] HrmGrade hrmgrade)
        {
            if (ModelState.IsValid)
            {
                db.Entry(hrmgrade).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return RedirectToAction("Index");
        }

        public ActionResult DeleteById(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            HrmGrade hrmgrade = db.HrmGrades.Find(id);
            if (hrmgrade == null)
            {
                return HttpNotFound();
            }
            return View(hrmgrade);
        }

        [HttpPost, ActionName("Delete")]
        //[ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int? GradeId)
        {
            HrmGrade hrmgrade = db.HrmGrades.Find(GradeId);
            hrmgrade.IsActive = false;
            db.HrmGrades.AddOrUpdate(hrmgrade);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
