﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DigiERp.Models;

namespace DigiERP.Controllers
{
    public class GoogleMapController : Controller
    {
        private DigiERPEntities db = new DigiERPEntities();
        public ActionResult GoogleMapView()
        {
            return View();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
	}
}