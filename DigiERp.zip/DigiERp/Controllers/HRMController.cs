﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using DigiERp.Models;

namespace DigiERP.Controllers
{
    public class HRMController : Controller
    {
        private DigiERPEntities db = new DigiERPEntities();

        public ActionResult Index()
        {
            var item = db.SysDynamicUIs.Where(m => (m.IsActive == true) && (m.ModuleId == 4)).ToList();
            return View(item);
        }
       
        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
