﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using DigiERp.Models;

namespace DigiERP.Controllers
{
    public class HomeController : Controller
    {
        DigiERPEntities dbEntities = new DigiERPEntities();

        //[Authorize]
        public ActionResult Index()
        {
            if (Session["LoginId"] != null)
            {
                //var c = dbEntities.SysDynamicCompanies.ToList();
                //var mo = dbEntities.SysDynamicModules.ToList();
                //var v = new CombineLayoutModel()
                //{
                //    DynamicCompanies = c,
                //    DynamicModules = mo
                //};
                //Session["layoutList"] = v;

                //Session["DC"] = dbEntities.SysDynamicCompanies;

                //TempData["c"] = dbEntities.SysDynamicCompanies.ToList();

                var modules = dbEntities.SysDynamicModules.Where(m => m.IsActive == true).ToList();
                return View(modules);
            }
            else
            {
                return RedirectToAction("LogIn", "User");
            }
            //return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }

        public ActionResult Dashboard()
        {
            ViewBag.Message = "Items page.";

            return View();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                dbEntities.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}