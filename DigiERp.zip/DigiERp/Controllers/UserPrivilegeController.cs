﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Migrations;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using DigiERp.Models;

namespace DigiERp.Controllers
{
    public class UserPrivilegeController : Controller
    {
        private DigiERPEntities dbEntities = new DigiERPEntities();
        public ActionResult Index(int? UiId)
        {
            var items = dbEntities.ViewSysUserPrivileges.ToList();
            ViewBag.UIList = dbEntities.SysDynamicUIs.Where(m => (m.IsActive == true) && (m.ModuleId == 4)).ToList();
            ViewBag.UserList = dbEntities.ViewSysUserRegistrations.ToList();
            var work = dbEntities.SysDynamicUIs.Where(w => w.UiId == UiId).FirstOrDefault();
            if (work != null)
            {
                ViewBag.WorkSheetName = work.UiName;
            }
            Session["UI"] = UiId;
            return View(items);
        }

        public ActionResult PrivilegeModule()
        {
            var item = dbEntities.SysDynamicModules.Where(m => m.ModuleName != null).ToList();
            ViewBag.UIList = dbEntities.SysDynamicUIs.Where(m => (m.IsActive == true) && (m.ModuleId == 4)).ToList();
            return View(item);
        }

        public ActionResult DynamicUI(int? ModuleId)
        {
            if (ModuleId != null)
            {
                var item = dbEntities.SysDynamicUIs.Where(m => m.ModuleId == ModuleId).ToList();
                ViewBag.UIList = dbEntities.SysDynamicUIs.Where(m => (m.IsActive == true) && (m.ModuleId == ModuleId)).ToList();
                return View(item);
            }
            return View();
        }

        public List<SelectListItem> GetWorkName()
        {
            List<SelectListItem> items = new List<SelectListItem>()
            {
                new SelectListItem() {Value = "", Text = "Work", Selected = true},
                new SelectListItem() {Value = "12", Text = "Prepared", Selected = false},
                new SelectListItem() {Value = "10", Text = "Check", Selected = false},
                new SelectListItem() {Value = "1", Text = "1st Recommended", Selected = false},
                new SelectListItem() {Value = "2", Text = "2nd Recommended", Selected = false},
                new SelectListItem() {Value = "3", Text = "3rd Recommended", Selected = false},
                new SelectListItem() {Value = "4", Text = "4th Recommended", Selected = false},
                new SelectListItem() {Value = "5", Text = "5th Recommended", Selected = false},
                new SelectListItem() {Value = "6", Text = "6th Recommended", Selected = false},
                new SelectListItem() {Value = "7", Text = "7th Recommended", Selected = false},
                new SelectListItem() {Value = "8", Text = "8th Recommended", Selected = false},
                new SelectListItem() {Value = "9", Text = "9th Recommended", Selected = false},
                new SelectListItem() {Value = "11", Text = "Approved", Selected = false}
            };
            return items;
        }

        public ActionResult PrivilegeUserById(int? UiId, int? UserId)
        {
            if (UserId != null)
            {
                var user = dbEntities.SysUserRegistrations.Where(u => u.UserId == UserId).FirstOrDefault();
                ViewBag.UserId = new SelectList(dbEntities.SysUserRegistrations, "UserId", "UserName",user.UserId);
                var userView = dbEntities.ViewSysUserRegistrations.Where(u => u.UserId == UserId).FirstOrDefault();
                ViewBag.deptName = userView.DepartmentName;
                ViewBag.degName = userView.DesignationName;
            }
            
            ViewBag.WorkId = GetWorkName();
            var work = dbEntities.SysDynamicUIs.Where(w => w.UiId == UiId).FirstOrDefault();
            if (work != null)
            {
                ViewBag.WorkSheetName = work.UiName;
            }
            var count = dbEntities.SysUserPrivileges.ToList();
            ViewBag.PrivilegeId = count.Count()+1;
            Session["UI"] = UiId;
            return View();
        }

        [HttpPost]
        public ActionResult PrivilegeUser(int? UiId, SysUserPrivilege sysUser)
        {
            var user = dbEntities.SysUserRegistrations.Where(u => u.UserId == sysUser.UserId).FirstOrDefault();
            sysUser.DepartmentId = user.DepartmentId;
            sysUser.DesignationId = user.DesignationId;
            dbEntities.SysUserPrivileges.Add(sysUser);
            dbEntities.SaveChanges();
            Session["UI"] = UiId;
            return RedirectToAction("Index", new { UiId = UiId});
        }

        public ActionResult EditById(int? UiId, int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            var privilege = dbEntities.SysUserPrivileges.Where(p => p.PrivilegeId == id).FirstOrDefault();
            if (privilege.UserId != null)
            {
                var user = dbEntities.SysUserRegistrations.Where(u => u.UserId == privilege.UserId).FirstOrDefault();
                ViewBag.UserId = new SelectList(dbEntities.SysUserRegistrations, "UserId", "UserName", user.UserId);
                var userView = dbEntities.ViewSysUserRegistrations.Where(u => u.UserId == privilege.UserId).FirstOrDefault();
                ViewBag.deptName = userView.DepartmentName;
                ViewBag.degName = userView.DesignationName;
            }
            ViewBag.WorkId = new SelectList(GetWorkName(), "Value", "Text", privilege.WorkId);
            Session["UI"] = UiId;
            return View(privilege);
        }

        [HttpPost]
        public ActionResult Edit(int? UiId, SysUserPrivilege sysUser)
        {
            var u = dbEntities.SysUserPrivileges.Where(x => x.PrivilegeId == sysUser.PrivilegeId).Single();

            //if (ModelState.IsValid)
            //{
            u.UserId = sysUser.UserId;
            u.WorkId = sysUser.WorkId;
            u.IsOnBehalf = sysUser.IsOnBehalf;
            u.IsNew = sysUser.IsNew;
            u.IsEdit = sysUser.IsEdit;
            u.IsDelete = sysUser.IsDelete;
            u.IsRevert = sysUser.IsRevert;
            u.IsReadOnly = sysUser.IsReadOnly;
            u.IsReport = sysUser.IsReport;
            u.IsPrint = sysUser.IsPrint;
            u.IsDisApprove = sysUser.IsDisApprove;
            u.IsActive = sysUser.IsActive;
            u.Condition = sysUser.Condition;
            dbEntities.SysUserPrivileges.AddOrUpdate(u);
            dbEntities.SaveChanges();
            //}
            Session["UI"] = UiId;
            return RedirectToAction("Index", new { UiId = UiId });
        }

        public ActionResult DeleteById(int? UiId, int? id)
        {
            var systemUserPrevilege = dbEntities.SysUserPrivileges.Find(id);
            Session["UI"] = UiId;
            return View(systemUserPrevilege);
        }

        [HttpPost]
        public ActionResult Delete(int? UiId, SysUserPrivilege sysUser)
        {
            var db = dbEntities.SysUserPrivileges.Where(m => m.PrivilegeId == sysUser.PrivilegeId).Single();
            db.IsActive = false;
            dbEntities.SysUserPrivileges.AddOrUpdate(db);
            dbEntities.SaveChanges();
            Session["UI"] = UiId;
            return RedirectToAction("Index", new { UiId = UiId });
        }
	}
}