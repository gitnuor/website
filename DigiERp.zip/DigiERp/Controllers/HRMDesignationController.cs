﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Data.Entity.Migrations;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using DigiERp.Models;

namespace DigiERp.Controllers
{
    public class HRMDesignationController : Controller
    {
        private DigiERPEntities db = new DigiERPEntities();

        public ActionResult Index()
        {
            ViewBag.UIList = db.SysDynamicUIs.Where(m => (m.IsActive == true) && (m.ModuleId == 4)).ToList();
            var designationList = db.HrmDesignations.Where(d => d.IsActive == true).ToList();
            return View(designationList);
        }

        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            HrmDesignation hrmdesignation = db.HrmDesignations.Find(id);
            if (hrmdesignation == null)
            {
                return HttpNotFound();
            }
            return View(hrmdesignation);
        }

        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        //[ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include="DesignationId,DesignationCode,DesignationName,GradeId,GradeGroupId,EntryUserId,EntryDate,EntryBy,UpdateDate,UpdateBy,DeleteBy,DeleteDate,CheckBy,CheckDate,CancelBy,CancelDate,ApproveBy,ApproveDate,IsActive,IsDeleted,IsApproved,IsCancel,WorkFollowPosition,IsSaleForce")] HrmDesignation hrmdesignation)
        {
            if (ModelState.IsValid)
            {
                db.HrmDesignations.Add(hrmdesignation);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(hrmdesignation);
        }

        public ActionResult EditById(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            HrmDesignation hrmdesignation = db.HrmDesignations.Find(id);
            if (hrmdesignation == null)
            {
                return HttpNotFound();
            }
            return View(hrmdesignation);
        }

        [HttpPost]
        //[ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include="DesignationId,DesignationCode,DesignationName,GradeId,GradeGroupId,EntryUserId,EntryDate,EntryBy,UpdateDate,UpdateBy,DeleteBy,DeleteDate,CheckBy,CheckDate,CancelBy,CancelDate,ApproveBy,ApproveDate,IsActive,IsDeleted,IsApproved,IsCancel,WorkFollowPosition,IsSaleForce")] HrmDesignation hrmdesignation)
        {
            if (ModelState.IsValid)
            {
                db.Entry(hrmdesignation).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return RedirectToAction("Index");
        }

        public ActionResult DeleteById(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            HrmDesignation hrmdesignation = db.HrmDesignations.Find(id);
            if (hrmdesignation == null)
            {
                return HttpNotFound();
            }
            return View(hrmdesignation);
        }

        [HttpPost, ActionName("Delete")]
        //[ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int? DesignationId)
        {
            if (DesignationId == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            HrmDesignation hrmdesignation = db.HrmDesignations.Find(DesignationId);
            if (hrmdesignation == null)
            {
                return HttpNotFound();
            }
            hrmdesignation.IsActive = false;
            db.HrmDesignations.AddOrUpdate(hrmdesignation);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
