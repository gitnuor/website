﻿using System;
using System.Collections.Generic;
using System.Data.Entity.Migrations;
using System.IO;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using System.Web.Security;
using DigiERp.Models;
using DigiERP.Models;

namespace DigiERP.Controllers
{
    public class UserController : Controller
    {
        private DigiERPEntities db = new DigiERPEntities();

        public ActionResult Index()
        {
            //var userList = db.SysUserRegistrations.Where(u => u.IsActive == true).ToList();
            var useer = from U in db.SysUserRegistrations
                join Dept in db.HrmDepartments on U.DepartmentId equals Dept.DepartmentId
                join Deg in db.HrmDesignations on U.DesignationId equals Deg.DesignationId
                where (U.DepartmentId == Dept.DepartmentId)&&(U.DesignationId == Deg.DesignationId) && (U.IsActive==true)
                select new UserListViewModel { UserRegistration = U,Department =Dept,Designation = Deg};

            ViewBag.UIList = db.SysDynamicUIs.Where(m => (m.IsActive == true) && (m.ModuleId == 4)).ToList();
            return View(useer);
        }

        public ActionResult Register()
        {
            ViewBag.DepartmentId = new SelectList(db.HrmDepartments, "DepartmentId", "DepartmentName");
            ViewBag.DesignationId = new SelectList(db.HrmDesignations, "DesignationId", "DesignationName");
            ViewBag.EmpId = new SelectList(db.HrmEmpApplications, "EmpId", "EmpName");
            ViewBag.UserId = new SelectList(db.SysUserRegistrations, "UserId", "UserName");
            ViewBag.UiId = new SelectList(db.SysDynamicUIs, "UiId", "UiCaption");
            return View();
        }
        [HttpPost]
        public ActionResult Register(SysUserRegistration user, HttpPostedFileBase signaturePath)
        {
                    var checkUser = (from s in db.SysUserRegistrations where s.LoginId == user.LoginId select s).FirstOrDefault();
                    if (checkUser == null)
                    {
                        var keyNew = Helper.GeneratePassword(10);
                        var password = Helper.EncodePassword(user.Password, keyNew);
                        user.Password = password;
                        user.VCode = keyNew;

                        if (signaturePath != null)
                        {
                            var signatureFileName = Path.GetFileName(signaturePath.FileName);
                            var path = Path.Combine(Server.MapPath("/SignaturePath/"), signatureFileName);
                            var folderPath = "~/SignaturePath/" + signatureFileName;
                            signaturePath.SaveAs(path);

                            user.SignaturePath = folderPath;
                        }
                        db.SysUserRegistrations.Add(user);
                        db.SaveChanges();
                        //ViewBag.Message = user.LoginId + " Successfully registered";
                        return RedirectToAction("Index");
                    }
                    else
                    {
                        ViewBag.Message = user.LoginId + " user aready exits";
                        //return RedirectToAction("Index");
                    }

                    ModelState.Clear();
             
            //ViewBag.DepartmentId = new SelectList(db.HrmDepartments, "DepartmentId", "DepartmentName");
            //ViewBag.DesignationId = new SelectList(db.HrmDesignations, "DesignationId", "DesignationName");
            //ViewBag.EmpId = new SelectList(db.HrmEmpApplications, "EmpId", "EmpName");
            //ViewBag.UserId = new SelectList(db.HrmEmpApplications, "UserId", "UserName");
            //ViewBag.UiId = new SelectList(db.SysDynamicUIs, "UiId", "UiCaption");
         
            return View();
        }

        public ActionResult LogIn()
        {
            var u = new SysUserRegistration();
            var c = db.SysDynamicCompanies.ToList();
            var view = new CombineLoginModel()
            {
                UserRegistration = u,
                DynamicCompanies = c
            };
            return View(view);

            //return View();
        }

        [HttpPost]
        public ActionResult LogIn(SysUserRegistration user)
        {
            //using (DigiERPEntities db = new DigiERPEntities())
            //{
            var anUser = db.SysUserRegistrations.FirstOrDefault(u => (u.LoginId == user.LoginId) && (u.IsActive == true));
            //var aPUser = db.SysUserPrivileges.FirstOrDefault(p => (p.UserId == anUser.UserId) && (p.IsActive == true));
            if (anUser != null)
            {
                {
                    var hashCode = anUser.VCode;
                    //Password Hasing Process Call Helper Class Method    
                    var encodingPasswordString = Helper.EncodePassword(user.Password, hashCode);
                    // user.Password = encodingPasswordString

                    var aUser = db.SysUserRegistrations.FirstOrDefault(u => u.LoginId == user.LoginId && u.Password.Equals(encodingPasswordString));
                    if (aUser != null)
                    {
                        Session["LoginId"] = aUser.LoginId.ToString();
                        Session["Password"] = aUser.Password.ToString();
                        return RedirectToAction("Index", "Home");
                    }
                    else
                    {
                        ViewBag.Message = "LoginId or Password is incorrect";
                    }
                }
            }
            else
            {
                ViewBag.Message = "Sorry your LoginId is not active now";
            }

            ModelState.Clear();
            //}

            //var u = new SysUserRegistration();
            var c = db.SysDynamicCompanies.ToList();
            var view = new CombineLoginModel()
            {
                UserRegistration = user,
                DynamicCompanies = c
            };
            return View(view);

            //return View();
        }

        public ActionResult LogOff()
        {
            FormsAuthentication.SignOut();
            Session.Abandon();
            return RedirectToAction("LogIn");
        }

        public ActionResult EditById(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }

            SysUserRegistration sysUserRegistration = db.SysUserRegistrations.Where(p => p.UserId == id).Single();
            ViewBag.DepartmentId = new SelectList(db.HrmDepartments, "DepartmentId", "DepartmentName",sysUserRegistration.DepartmentId);
            ViewBag.DesignationId = new SelectList(db.HrmDesignations, "DesignationId", "DesignationName",sysUserRegistration.DesignationId);
            ViewBag.EmpId = new SelectList(db.HrmEmpApplications, "EmpId", "EmpName",sysUserRegistration.EmpId);
            ViewBag.UserId = new SelectList(db.SysUserRegistrations, "UserId", "UserName",sysUserRegistration.UserId);

            sysUserRegistration.Password = null;
            sysUserRegistration.VCode = null;

            if (sysUserRegistration == null)
            {
                return HttpNotFound();
            }
            return View(sysUserRegistration);
        }

        [HttpPost]
        public ActionResult Edit(SysUserRegistration sysUserRegistration)
        {
            var existingUser = db.SysUserRegistrations.Where(p => p.UserId == sysUserRegistration.UserId).Single();

                if (sysUserRegistration.Password == null)
                {
                   existingUser.Password = existingUser.Password;
                   existingUser.VCode = existingUser.VCode;
                }
                else
                {
                    var keyNew = Helper.GeneratePassword(10);
                    var password = Helper.EncodePassword(sysUserRegistration.Password, keyNew);
                    existingUser.Password = password;
                    existingUser.VCode = keyNew;
                }
                existingUser.LoginId = sysUserRegistration.LoginId;
                existingUser.UserName = sysUserRegistration.UserName;
                existingUser.EmpId = sysUserRegistration.EmpId;
                existingUser.DesignationId = sysUserRegistration.DesignationId;
                existingUser.DepartmentId = sysUserRegistration.DepartmentId;
                existingUser.IsActive = sysUserRegistration.IsActive;
                existingUser.IsDeleted = sysUserRegistration.IsDeleted;
                existingUser.IsApproved = sysUserRegistration.IsApproved;
                db.SysUserRegistrations.AddOrUpdate(existingUser);
                db.SaveChanges();
                //ViewBag.DepartmentId = new SelectList(db.HrmDepartments, "DepartmentId", "DepartmentName");
                //ViewBag.DesignationId = new SelectList(db.HrmDesignations, "DesignationId", "DesignationName");
                //ViewBag.EmpId = new SelectList(db.HrmEmpApplications, "EmpId", "EmpName");
                //ViewBag.UserId = new SelectList(db.SysUserRegistrations, "UserId", "UserName");
                return RedirectToAction("Index");
            }

        public ActionResult DeleteById(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            SysUserRegistration sysuserregistration = db.SysUserRegistrations.Find(id);
            if (sysuserregistration == null)
            {
                return HttpNotFound();
            }
            return View(sysuserregistration);
        }

        [HttpPost, ActionName("Delete")]
        public ActionResult DeleteConfirmed(SysUserRegistration sysUserRegistration)
        {
            if (ModelState.IsValid)
            {
                SysUserRegistration sysuserregistration = db.SysUserRegistrations.Find(sysUserRegistration.UserId);
                if (sysuserregistration != null)
                {
                    sysuserregistration.IsActive = false;
                    db.SysUserRegistrations.AddOrUpdate(sysuserregistration);
                    db.SaveChanges();
                    return RedirectToAction("Index");
                }
            }
            return View();
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
	}
}